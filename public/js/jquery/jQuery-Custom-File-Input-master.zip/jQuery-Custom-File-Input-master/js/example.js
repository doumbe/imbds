$(function(){
		$('#file').customFileInput();	
});